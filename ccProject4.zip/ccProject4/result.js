document.addEventListener("DOMContentLoaded",function(){

    let dice = localStorage.getItem("dice")

    console.log(dice)

})